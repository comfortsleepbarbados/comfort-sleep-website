/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'images.pexels.com',
      },
      {
        protocol: 'https',
        hostname: 'www.comfortsleepbarbados.com',
      },
    ],
  },
  output: 'export',
};

module.exports = nextConfig;
