'use client';

import Link from 'next/link';
import { Factory, Award, Globe, Users, Target, Heart, TrendingUp, Shield } from 'lucide-react';

const values = [
  {
    icon: Target,
    title: 'Quality First',
    description: 'We never compromise on materials, construction, or testing. Every mattress meets rigorous international standards.',
  },
  {
    icon: Heart,
    title: 'Caribbean Pride',
    description: 'Manufactured in Guyana by Comfort Sleep, distributed regionally from Barbados, supporting Caribbean economies while delivering world-class hospitality products.',
  },
  {
    icon: Users,
    title: 'Partnership Approach',
    description: 'We view our clients as long-term partners, not transactions. Your success is our success.',
  },
  {
    icon: TrendingUp,
    title: 'Continuous Innovation',
    description: 'Ongoing investment in R&D to improve climate performance and durability for tropical environments.',
  },
];

const milestones = [
  {
    year: '2010',
    title: 'Company Founded',
    description: 'Established in Bridgetown, Barbados with a vision to serve Caribbean hospitality.',
  },
  {
    year: '2013',
    title: 'EPA Certification',
    description: 'Achieved EPA certification for foam safety and environmental standards.',
  },
  {
    year: '2016',
    title: 'ISO 9001 Certified',
    description: 'International quality management certification for manufacturing excellence.',
  },
  {
    year: '2018',
    title: 'Regional Expansion',
    description: 'Began serving properties across 12 Caribbean islands.',
  },
  {
    year: '2020',
    title: 'Marriott Supplier',
    description: 'Approved as official supplier for Marriott properties in the Caribbean.',
  },
  {
    year: '2025',
    title: '250+ Properties Served',
    description: 'Trusted by leading hotels, resorts, and luxury villas across the region.',
  },
];

const team = [
  {
    name: 'Marcus Thompson',
    role: 'Founder & CEO',
    bio: '25+ years in hospitality procurement and Caribbean manufacturing.',
  },
  {
    name: 'Sophia Martinez',
    role: 'Director of Hospitality Sales',
    bio: 'Former hotel GM with deep understanding of property operations.',
  },
  {
    name: 'David Chen',
    role: 'Head of Manufacturing',
    bio: 'International mattress industry veteran with expertise in tropical climate engineering.',
  },
  {
    name: 'Lisa Williams',
    role: 'Customer Success Manager',
    bio: 'Dedicated to ensuring every client receives exceptional support and service.',
  },
];

export default function About() {
  return (
    <div className="pt-20">
      <section className="relative h-[60vh] bg-gradient-to-br from-gray-900 to-gray-800 flex items-center">
        <div className="absolute inset-0 bg-black/40 z-0"></div>
        <div
          className="absolute inset-0 z-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('https://images.pexels.com/photos/6585608/pexels-photo-6585608.jpeg?auto=compress&cs=tinysrgb&w=1920')",
          }}
        ></div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            About Comfort Sleep Barbados
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 max-w-2xl">
            Premium hospitality mattresses manufactured in Guyana, distributed from Barbados across the Caribbean.
          </p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Our Story
              </h2>
              <div className="space-y-4 text-lg text-gray-600">
                <p>
                  Comfort Sleep Barbados was founded in 2010 with a simple observation: Caribbean hotels were paying premium prices for imported mattresses that failed quickly in tropical conditions.
                </p>
                <p>
                  Our founder, Marcus Thompson, spent 15 years as a procurement director for a major Caribbean hotel chain. He watched properties replace expensive imported mattresses every 2-3 years due to humidity damage, mold, and rapid deterioration.
                </p>
                <p>
                  He knew there had to be a better way. Partnering with Comfort Sleep's manufacturing facility in Guyana and working with international foam engineers, we developed mattresses specifically engineered for Caribbean climate conditions.
                </p>
                <p>
                  Today, we distribute premium mattresses manufactured by Comfort Sleep in Guyana to hospitality properties across Barbados and throughout the Caribbean region, serving boutique hotels, luxury resorts, and vacation rental managers across 12 islands.
                </p>
              </div>
            </div>

            <div className="relative h-96 rounded-lg overflow-hidden shadow-xl">
              <img
                src="https://images.pexels.com/photos/1267338/pexels-photo-1267338.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Manufacturing facility"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Our Values
            </h2>
            <p className="text-xl text-gray-600">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value) => (
              <div key={value.title} className="bg-white p-8 rounded-lg shadow-md">
                <div className="bg-[#25278C]/10 w-14 h-14 rounded-full flex items-center justify-center mb-4">
                  <value.icon className="w-7 h-7 text-[#25278C]" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-gray-900">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Our Journey
            </h2>
            <p className="text-xl text-gray-600">
              15 years of innovation and growth
            </p>
          </div>

          <div className="relative">
            <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-gray-200"></div>

            <div className="space-y-12">
              {milestones.map((milestone, index) => (
                <div
                  key={milestone.year}
                  className={`flex flex-col md:flex-row gap-8 items-center ${
                    index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                  }`}
                >
                  <div className={`flex-1 ${index % 2 === 0 ? 'md:text-right' : 'md:text-left'}`}>
                    <div className="bg-gray-50 p-6 rounded-lg">
                      <h3 className="text-2xl font-bold text-gray-900 mb-2">{milestone.title}</h3>
                      <p className="text-gray-600">{milestone.description}</p>
                    </div>
                  </div>

                  <div className="flex-shrink-0 w-20 h-20 bg-[#25278C] text-white rounded-full flex items-center justify-center text-xl font-bold z-10">
                    {milestone.year}
                  </div>

                  <div className="flex-1"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-[#25278C] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">
              By the Numbers
            </h2>
            <p className="text-xl text-gray-200">
              The impact we've made across the Caribbean
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <Factory className="w-12 h-12 mx-auto mb-4" />
              <div className="text-5xl font-bold mb-2">50,000+</div>
              <div className="text-gray-200">Mattresses Manufactured</div>
            </div>
            <div className="text-center">
              <Globe className="w-12 h-12 mx-auto mb-4" />
              <div className="text-5xl font-bold mb-2">12</div>
              <div className="text-gray-200">Caribbean Islands Served</div>
            </div>
            <div className="text-center">
              <Award className="w-12 h-12 mx-auto mb-4" />
              <div className="text-5xl font-bold mb-2">250+</div>
              <div className="text-gray-200">Properties Equipped</div>
            </div>
            <div className="text-center">
              <Shield className="w-12 h-12 mx-auto mb-4" />
              <div className="text-5xl font-bold mb-2">98%</div>
              <div className="text-gray-200">Client Satisfaction Rate</div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Meet Our Leadership Team
            </h2>
            <p className="text-xl text-gray-600">
              Industry veterans committed to Caribbean hospitality excellence
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {team.map((member) => (
              <div key={member.name} className="bg-white p-8 rounded-lg shadow-md">
                <div className="flex items-center mb-4">
                  <div className="w-20 h-20 bg-[#25278C] rounded-full flex items-center justify-center text-white text-2xl font-bold mr-4">
                    {member.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">{member.name}</h3>
                    <p className="text-[#25278C] font-semibold">{member.role}</p>
                  </div>
                </div>
                <p className="text-gray-600">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative h-96 rounded-lg overflow-hidden shadow-xl">
              <img
                src="https://images.pexels.com/photos/3183197/pexels-photo-3183197.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Manufacturing quality control"
                className="w-full h-full object-cover"
              />
            </div>

            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Manufacturing Excellence
              </h2>
              <div className="space-y-4 text-lg text-gray-600">
                <p>
                  Our mattresses are manufactured by Comfort Sleep at their state-of-the-art facility in Guyana, combining modern equipment with rigorous quality control processes.
                </p>
                <p>
                  Every mattress is inspected at multiple stages of production. The quality assurance team tests compression resistance, foam density, and climate performance before any unit is shipped.
                </p>
                <p>
                  We work exclusively with EPA and ISO 9001 certified manufacturing partners, ensuring continuous monitoring and improvement of production processes. From Barbados, we handle regional distribution and provide local support across the Caribbean.
                </p>
              </div>

              <div className="mt-8 grid grid-cols-2 gap-6">
                <div className="border-l-4 border-[#25278C] pl-4">
                  <div className="text-3xl font-bold text-[#25278C] mb-1">100%</div>
                  <div className="text-gray-600">Units Inspected</div>
                </div>
                <div className="border-l-4 border-[#25278C] pl-4">
                  <div className="text-3xl font-bold text-[#25278C] mb-1">45</div>
                  <div className="text-gray-600">Team Members</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-[#25278C] to-[#1a1c66] text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">
            Partner With Us
          </h2>
          <p className="text-xl mb-8 text-gray-200">
            Join 250+ Caribbean properties that trust Comfort Sleep for their guest experience.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/contact"
              className="bg-white hover:bg-gray-100 text-[#25278C] px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Request Quote
            </Link>
            <Link
              href="/hotel-line"
              className="border-2 border-white hover:bg-white hover:text-[#25278C] text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              View Hotel Line
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
