'use client';

import Link from 'next/link';
import { Check, Shield, Droplets, Wind, ThermometerSun, Award } from 'lucide-react';

const consumerProducts = [
  {
    name: 'Comfort Classic',
    description: 'Perfect for everyday comfort in Caribbean homes',
    features: [
      'High-density foam core',
      'Breathable quilted cover',
      'Moisture-wicking fabric',
      'Anti-microbial treatment',
      '5-year warranty'
    ],
    sizes: ['Twin', 'Full', 'Queen', 'King'],
    priceRange: 'BBD $599 - $1,299',
    image: 'https://images.pexels.com/photos/1148955/pexels-photo-1148955.jpeg?auto=compress&cs=tinysrgb&w=1200'
  },
  {
    name: 'Cool Breeze Elite',
    description: 'Premium cooling technology for tropical climates',
    features: [
      'Advanced cooling gel infusion',
      'Extra breathable design',
      'Edge support system',
      'Hypoallergenic materials',
      '7-year warranty'
    ],
    sizes: ['Queen', 'King'],
    priceRange: 'BBD $1,499 - $1,999',
    image: 'https://images.pexels.com/photos/6585608/pexels-photo-6585608.jpeg?auto=compress&cs=tinysrgb&w=1200'
  },
  {
    name: 'Island Luxury',
    description: 'Ultra-premium comfort with advanced climate engineering',
    features: [
      'Multi-layer comfort system',
      'Maximum airflow technology',
      'Reinforced support zones',
      'Premium quilted Euro-top',
      '10-year warranty'
    ],
    sizes: ['Queen', 'King', 'California King'],
    priceRange: 'BBD $2,299 - $2,999',
    image: 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&w=1200'
  }
];

export default function Products() {
  return (
    <div className="pt-20">
      <section className="relative h-[60vh] bg-gradient-to-br from-gray-900 to-gray-800 flex items-center">
        <div className="absolute inset-0 bg-black/40 z-0"></div>
        <div
          className="absolute inset-0 z-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('https://images.pexels.com/photos/1743231/pexels-photo-1743231.jpeg?auto=compress&cs=tinysrgb&w=1920')",
          }}
        ></div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Consumer Mattress Collection
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 max-w-2xl">
            Premium comfort engineered for Caribbean homes. EPA certified, climate-tested, and built to last.
          </p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Choose Comfort Sleep?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Caribbean-manufactured mattresses designed specifically for tropical climate challenges
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            <div className="text-center">
              <div className="bg-[#25278C]/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Droplets className="w-8 h-8 text-[#25278C]" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Humidity Resistant</h3>
              <p className="text-gray-600 text-sm">Engineered to resist tropical moisture and prevent mold</p>
            </div>

            <div className="text-center">
              <div className="bg-[#25278C]/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Wind className="w-8 h-8 text-[#25278C]" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Maximum Airflow</h3>
              <p className="text-gray-600 text-sm">Enhanced breathability keeps you cool all night</p>
            </div>

            <div className="text-center">
              <div className="bg-[#25278C]/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <ThermometerSun className="w-8 h-8 text-[#25278C]" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Heat Dissipation</h3>
              <p className="text-gray-600 text-sm">Advanced cooling technology for tropical nights</p>
            </div>

            <div className="text-center">
              <div className="bg-[#25278C]/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-[#25278C]" />
              </div>
              <h3 className="text-lg font-semibold mb-2">EPA Certified</h3>
              <p className="text-gray-600 text-sm">Safe materials meeting international standards</p>
            </div>
          </div>

          <div className="space-y-12">
            {consumerProducts.map((product, index) => (
              <div
                key={index}
                className={`grid grid-cols-1 lg:grid-cols-2 gap-8 items-center ${
                  index % 2 === 1 ? 'lg:flex-row-reverse' : ''
                }`}
              >
                <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                  <div className="relative h-96 rounded-lg overflow-hidden shadow-xl">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>

                <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                  <h3 className="text-3xl font-bold text-gray-900 mb-4">{product.name}</h3>
                  <p className="text-xl text-gray-600 mb-6">{product.description}</p>

                  <div className="bg-gray-50 rounded-lg p-6 mb-6">
                    <h4 className="font-semibold text-gray-900 mb-4">Key Features:</h4>
                    <ul className="space-y-3">
                      {product.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start">
                          <Check className="w-5 h-5 text-[#25278C] mr-3 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="mb-6">
                    <p className="text-sm font-semibold text-gray-700 mb-2">Available Sizes:</p>
                    <div className="flex flex-wrap gap-2">
                      {product.sizes.map((size, idx) => (
                        <span
                          key={idx}
                          className="bg-white border-2 border-[#25278C] text-[#25278C] px-4 py-2 rounded-lg text-sm font-semibold"
                        >
                          {size}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="mb-6">
                    <p className="text-2xl font-bold text-[#25278C]">{product.priceRange}</p>
                    <p className="text-sm text-gray-500">Price varies by size</p>
                  </div>

                  <Link
                    href="/contact"
                    className="bg-[#25278C] hover:bg-[#1a1c66] text-white px-8 py-3 rounded-lg font-semibold transition-colors inline-block"
                  >
                    Request Quote
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold mb-6">Looking for Hotel Solutions?</h2>
              <p className="text-xl text-gray-300 mb-8">
                Our Hotel Elite Line is specifically engineered for high-turnover hospitality environments with CARICOM pricing advantages.
              </p>
              <Link
                href="/hotel-line"
                className="bg-white hover:bg-gray-100 text-[#25278C] px-8 py-3 rounded-lg font-semibold transition-colors inline-block"
              >
                Explore Hotel Line
              </Link>
            </div>
            <div className="relative h-96 rounded-lg overflow-hidden shadow-2xl">
              <img
                src="https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Luxury hotel bedroom"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#25278C]/5 rounded-2xl p-12 text-center">
            <Award className="w-16 h-16 text-[#25278C] mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Quality You Can Trust
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              All Comfort Sleep mattresses come with comprehensive warranties, EPA certification, and are manufactured to ISO 9001 standards in our Guyana facility.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/warranty"
                className="bg-[#25278C] hover:bg-[#1a1c66] text-white px-8 py-3 rounded-lg font-semibold transition-colors"
              >
                View Warranty Details
              </Link>
              <Link
                href="/contact"
                className="border-2 border-[#25278C] text-[#25278C] hover:bg-[#25278C] hover:text-white px-8 py-3 rounded-lg font-semibold transition-colors"
              >
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
