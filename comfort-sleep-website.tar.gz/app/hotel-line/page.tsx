'use client';

import Link from 'next/link';
import { Check, Shield, Award, TrendingUp, Clock, Building2, Truck, Users } from 'lucide-react';

const hotelProducts = [
  {
    name: 'Hotel Comfort',
    tier: 'Entry Level',
    description: 'Reliable comfort for budget-conscious properties',
    features: [
      'High-density support foam',
      'Durable quilted cover',
      'Anti-microbial protection',
      'Edge reinforcement',
      '5-year commercial warranty',
      'High turnover tested'
    ],
    specs: {
      density: '1.8 lb/ft³',
      height: '8 inches',
      firmness: 'Medium-Firm'
    },
    priceRange: 'BBD $450 - $650',
    idealFor: 'Guesthouses, Budget Hotels, Vacation Rentals',
    image: 'https://images.pexels.com/photos/1743231/pexels-photo-1743231.jpeg?auto=compress&cs=tinysrgb&w=1200'
  },
  {
    name: 'Hotel Elite',
    tier: 'Premium',
    description: 'Superior comfort for upscale hospitality',
    features: [
      'Multi-layer comfort system',
      'Advanced cooling technology',
      'Premium quilted top',
      'Reinforced edge support',
      '7-year commercial warranty',
      'Marriott-approved quality'
    ],
    specs: {
      density: '2.2 lb/ft³',
      height: '10 inches',
      firmness: 'Medium'
    },
    priceRange: 'BBD $750 - $950',
    idealFor: 'Boutique Hotels, Resort Properties, 4-Star Establishments',
    image: 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&w=1200'
  },
  {
    name: 'Hotel Luxury',
    tier: 'Ultra-Premium',
    description: 'Exceptional comfort for luxury resorts',
    features: [
      'Multi-zone support system',
      'Maximum cooling gel infusion',
      'Euro-pillow top design',
      'Lifetime edge guarantee',
      '10-year commercial warranty',
      '5-star resort standard'
    ],
    specs: {
      density: '2.5 lb/ft³',
      height: '12 inches',
      firmness: 'Plush Medium'
    },
    priceRange: 'BBD $1,200 - $1,500',
    idealFor: 'Luxury Resorts, 5-Star Hotels, Premium Villas',
    image: 'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=1200'
  }
];

const caricomBenefits = [
  {
    title: 'Zero Import Duties',
    description: 'Save 20-35% compared to international suppliers',
    icon: TrendingUp
  },
  {
    title: 'Fast Delivery',
    description: '2-3 weeks for bulk orders across the Caribbean',
    icon: Clock
  },
  {
    title: 'Regional Support',
    description: 'Caribbean-based warranty service and replacements',
    icon: Building2
  },
  {
    title: 'Flexible Terms',
    description: 'Payment plans available for qualified properties',
    icon: Users
  }
];

export default function HotelLine() {
  return (
    <div className="pt-20">
      <section className="relative h-[70vh] bg-gradient-to-br from-gray-900 to-gray-800 flex items-center">
        <div className="absolute inset-0 bg-black/50 z-0"></div>
        <div
          className="absolute inset-0 z-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&w=1920')",
          }}
        ></div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
          <div className="max-w-3xl">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Hotel Elite Line
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 mb-8">
              Climate-engineered mattresses for Caribbean hospitality. Built for high turnover, tropical humidity, and five-star guest expectations.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                href="/contact"
                className="bg-[#25278C] hover:bg-[#1a1c66] text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors text-center"
              >
                Request Bulk Quote
              </Link>
              <Link
                href="/pilot-program"
                className="bg-white hover:bg-gray-100 text-gray-900 px-8 py-4 rounded-lg text-lg font-semibold transition-colors text-center"
              >
                Try Our Pilot Program
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">The CARICOM Advantage</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Manufactured in Guyana, distributed from Barbados. Premium quality at regional prices.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {caricomBenefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <div key={index} className="text-center">
                  <div className="bg-[#25278C]/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-8 h-8 text-[#25278C]" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
                  <p className="text-gray-600">{benefit.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Choose Your Tier</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Three quality levels to match your property standards and budget
            </p>
          </div>

          <div className="space-y-16">
            {hotelProducts.map((product, index) => (
              <div
                key={index}
                className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${
                  index % 2 === 1 ? 'lg:flex-row-reverse' : ''
                }`}
              >
                <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                  <div className="relative h-96 rounded-lg overflow-hidden shadow-2xl">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-4 left-4 bg-[#25278C] text-white px-4 py-2 rounded-lg font-semibold">
                      {product.tier}
                    </div>
                  </div>
                </div>

                <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                  <h3 className="text-4xl font-bold text-gray-900 mb-3">{product.name}</h3>
                  <p className="text-xl text-gray-600 mb-6">{product.description}</p>

                  <div className="bg-white rounded-lg p-6 shadow-md mb-6">
                    <h4 className="font-semibold text-gray-900 mb-4 flex items-center">
                      <Shield className="w-5 h-5 text-[#25278C] mr-2" />
                      Key Features
                    </h4>
                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {product.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start">
                          <Check className="w-5 h-5 text-[#25278C] mr-2 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-700 text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-white rounded-lg p-6 shadow-md mb-6">
                    <h4 className="font-semibold text-gray-900 mb-3">Specifications</h4>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-gray-500 mb-1">Density</p>
                        <p className="font-semibold text-gray-900">{product.specs.density}</p>
                      </div>
                      <div>
                        <p className="text-gray-500 mb-1">Height</p>
                        <p className="font-semibold text-gray-900">{product.specs.height}</p>
                      </div>
                      <div>
                        <p className="text-gray-500 mb-1">Firmness</p>
                        <p className="font-semibold text-gray-900">{product.specs.firmness}</p>
                      </div>
                    </div>
                  </div>

                  <div className="mb-6">
                    <p className="text-sm font-semibold text-gray-700 mb-2">Ideal For:</p>
                    <p className="text-gray-600">{product.idealFor}</p>
                  </div>

                  <div className="flex items-baseline gap-4 mb-6">
                    <p className="text-3xl font-bold text-[#25278C]">{product.priceRange}</p>
                    <p className="text-sm text-gray-500">per mattress (20+ units)</p>
                  </div>

                  <Link
                    href="/contact"
                    className="bg-[#25278C] hover:bg-[#1a1c66] text-white px-8 py-3 rounded-lg font-semibold transition-colors inline-block"
                  >
                    Request Quote for {product.name}
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Engineered for Caribbean Conditions</h2>
              <div className="space-y-4">
                <div className="flex items-start">
                  <Check className="w-6 h-6 text-[#25278C] mr-3 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">Humidity Resistance</h4>
                    <p className="text-gray-600">Specialized foam composition prevents mold and maintains structure in 80%+ humidity</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Check className="w-6 h-6 text-[#25278C] mr-3 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">High Turnover Durability</h4>
                    <p className="text-gray-600">Tested for 90%+ occupancy rates with guest weights up to 300 lbs</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Check className="w-6 h-6 text-[#25278C] mr-3 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">Heat Dissipation</h4>
                    <p className="text-gray-600">Enhanced airflow design keeps guests comfortable in tropical temperatures</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Check className="w-6 h-6 text-[#25278C] mr-3 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">Easy Maintenance</h4>
                    <p className="text-gray-600">Removable covers and stain-resistant fabrics for housekeeping efficiency</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative h-[500px] rounded-lg overflow-hidden shadow-2xl">
              <img
                src="https://images.pexels.com/photos/1457842/pexels-photo-1457842.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Luxury hotel room"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-[#25278C] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Award className="w-16 h-16 mx-auto mb-6" />
            <h2 className="text-4xl font-bold mb-4">Trusted By Leading Caribbean Brands</h2>
            <p className="text-xl text-gray-200">250+ properties across 12 Caribbean islands</p>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 max-w-4xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
              <div className="text-center">
                <div className="text-4xl font-bold mb-2">15,000+</div>
                <div className="text-gray-200 text-sm">Mattresses Delivered</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold mb-2">250+</div>
                <div className="text-gray-200 text-sm">Properties Served</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold mb-2">98%</div>
                <div className="text-gray-200 text-sm">Satisfaction Rate</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold mb-2">7 Years</div>
                <div className="text-gray-200 text-sm">Avg. Warranty</div>
              </div>
            </div>

            <div className="border-t border-white/20 pt-6">
              <p className="text-lg italic mb-4">
                "We replaced all 120 rooms with Comfort Sleep's Hotel Elite line three years ago. The quality remains exceptional, guest feedback has been overwhelmingly positive, and the CARICOM pricing made the investment possible. Best decision we've made for guest experience."
              </p>
              <div className="flex items-center">
                <Building2 className="w-12 h-12 text-white/60 mr-4" />
                <div>
                  <div className="font-semibold">Michael Richards</div>
                  <div className="text-gray-300 text-sm">General Manager, Crane Resort, Barbados</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-50 rounded-xl p-8 text-center">
              <Truck className="w-12 h-12 text-[#25278C] mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Bulk Pricing</h3>
              <p className="text-gray-600 mb-6">
                Volume discounts start at 20 units. Larger orders qualify for enhanced terms and expedited delivery.
              </p>
              <Link
                href="/contact"
                className="text-[#25278C] font-semibold hover:underline"
              >
                Get Volume Quote →
              </Link>
            </div>

            <div className="bg-gray-50 rounded-xl p-8 text-center">
              <Shield className="w-12 h-12 text-[#25278C] mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Commercial Warranty</h3>
              <p className="text-gray-600 mb-6">
                Comprehensive coverage designed for hospitality. Transferable between property owners.
              </p>
              <Link
                href="/warranty"
                className="text-[#25278C] font-semibold hover:underline"
              >
                Learn More →
              </Link>
            </div>

            <div className="bg-gray-50 rounded-xl p-8 text-center">
              <Award className="w-12 h-12 text-[#25278C] mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Pilot Program</h3>
              <p className="text-gray-600 mb-6">
                Test our Hotel Line in select rooms for 90 days before committing to a full property order.
              </p>
              <Link
                href="/pilot-program"
                className="text-[#25278C] font-semibold hover:underline"
              >
                Apply Now →
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-[#25278C] to-[#1a1c66] text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Elevate Your Guest Experience?</h2>
          <p className="text-xl mb-8 text-gray-200">
            Schedule a consultation with our hospitality team. We'll help you choose the right tier and quantities for your property.
          </p>
          <Link
            href="/contact"
            className="bg-white hover:bg-gray-100 text-[#25278C] px-8 py-4 rounded-lg text-lg font-semibold transition-colors inline-block"
          >
            Schedule Consultation
          </Link>
        </div>
      </section>
    </div>
  );
}
