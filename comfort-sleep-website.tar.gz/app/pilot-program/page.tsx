'use client';

import Link from 'next/link';
import { Check, Clock, Package, BarChart3, Shield, FileText, Truck, Award } from 'lucide-react';

const programBenefits = [
  {
    icon: Package,
    title: 'Risk-Free Trial',
    description: 'Test our mattresses in actual guest rooms with no upfront commitment'
  },
  {
    icon: BarChart3,
    title: 'Guest Feedback',
    description: 'Collect real guest satisfaction data before making a full purchase decision'
  },
  {
    icon: Clock,
    title: '90-Day Period',
    description: 'Three full months to evaluate performance across different guest types'
  },
  {
    icon: Shield,
    title: 'Full Support',
    description: 'Dedicated account manager and technical support throughout the trial'
  }
];

const howItWorks = [
  {
    step: 1,
    title: 'Submit Application',
    description: 'Complete our simple application form with your property details and requirements',
    duration: '1 day'
  },
  {
    step: 2,
    title: 'Property Assessment',
    description: 'Our team evaluates your property and recommends the optimal product tier for testing',
    duration: '3-5 days'
  },
  {
    step: 3,
    title: 'Trial Setup',
    description: 'We deliver and install trial mattresses in your selected rooms at no cost',
    duration: '1-2 weeks'
  },
  {
    step: 4,
    title: '90-Day Evaluation',
    description: 'Use the mattresses in live guest rooms while collecting feedback and performance data',
    duration: '90 days'
  },
  {
    step: 5,
    title: 'Review & Decision',
    description: 'Review results with our team and decide on full property purchase with special pilot pricing',
    duration: '1 week'
  }
];

const eligibility = [
  'Hotels, resorts, or guesthouses with 15+ rooms',
  'Properties located in CARICOM member states',
  'Willingness to collect guest feedback systematically',
  'Commitment to making a purchase decision within 90 days',
  'At least 3 rooms available for trial mattresses'
];

export default function PilotProgram() {
  return (
    <div className="pt-20">
      <section className="relative h-[70vh] bg-gradient-to-br from-gray-900 to-gray-800 flex items-center">
        <div className="absolute inset-0 bg-black/50 z-0"></div>
        <div
          className="absolute inset-0 z-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('https://images.pexels.com/photos/1457842/pexels-photo-1457842.jpeg?auto=compress&cs=tinysrgb&w=1920')",
          }}
        ></div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
          <div className="max-w-3xl">
            <div className="bg-[#25278C] text-white px-4 py-2 rounded-lg font-semibold inline-block mb-6">
              Risk-Free Hotel Trial Program
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Try Before You Buy
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 mb-8">
              Test our Hotel Elite mattresses in your property for 90 days with zero upfront cost. See the quality, collect guest feedback, then make your decision.
            </p>
            <Link
              href="/contact"
              className="bg-[#25278C] hover:bg-[#1a1c66] text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors inline-block"
            >
              Apply for Pilot Program
            </Link>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Join Our Pilot Program?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Make confident purchasing decisions backed by real guest experience data
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {programBenefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <div key={index} className="text-center">
                  <div className="bg-[#25278C]/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-8 h-8 text-[#25278C]" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{benefit.title}</h3>
                  <p className="text-gray-600">{benefit.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How the Program Works</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              A simple, transparent process from application to purchase decision
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              {howItWorks.map((item, index) => (
                <div key={index} className="relative">
                  {index !== howItWorks.length - 1 && (
                    <div className="hidden md:block absolute left-8 top-20 w-0.5 h-full bg-[#25278C]/20"></div>
                  )}
                  <div className="flex gap-6 items-start">
                    <div className="flex-shrink-0 w-16 h-16 bg-[#25278C] text-white rounded-full flex items-center justify-center text-2xl font-bold relative z-10">
                      {item.step}
                    </div>
                    <div className="flex-1 bg-white rounded-lg p-6 shadow-md">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="text-2xl font-bold text-gray-900">{item.title}</h3>
                        <span className="bg-[#25278C]/10 text-[#25278C] px-3 py-1 rounded-full text-sm font-semibold">
                          {item.duration}
                        </span>
                      </div>
                      <p className="text-gray-600">{item.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">What You Get During the Trial</h2>
              <div className="space-y-4">
                <div className="flex items-start">
                  <Check className="w-6 h-6 text-[#25278C] mr-3 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">3-10 Trial Mattresses</h4>
                    <p className="text-gray-600">Depending on property size, strategically placed across different room types</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Check className="w-6 h-6 text-[#25278C] mr-3 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">Free Delivery & Installation</h4>
                    <p className="text-gray-600">Complete setup with mattress protectors and professional installation</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Check className="w-6 h-6 text-[#25278C] mr-3 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">Guest Feedback Tools</h4>
                    <p className="text-gray-600">QR codes and survey forms to collect real guest satisfaction data</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Check className="w-6 h-6 text-[#25278C] mr-3 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">Dedicated Account Manager</h4>
                    <p className="text-gray-600">Weekly check-ins and support throughout the 90-day period</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Check className="w-6 h-6 text-[#25278C] mr-3 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">Performance Analytics</h4>
                    <p className="text-gray-600">Detailed reporting on guest feedback trends and satisfaction scores</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Check className="w-6 h-6 text-[#25278C] mr-3 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">Exclusive Pilot Pricing</h4>
                    <p className="text-gray-600">Special discount on full property order upon program completion</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative h-[600px] rounded-lg overflow-hidden shadow-2xl">
              <img
                src="https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Luxury hotel bedroom"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-[#25278C] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <FileText className="w-16 h-16 mx-auto mb-6" />
              <h2 className="text-4xl font-bold mb-4">Eligibility Requirements</h2>
              <p className="text-xl text-gray-200">
                We're looking for properties committed to delivering exceptional guest experiences
              </p>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8">
              <ul className="space-y-4">
                {eligibility.map((item, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="w-6 h-6 mr-3 flex-shrink-0 mt-0.5" />
                    <span className="text-lg">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-50 rounded-xl p-8 text-center">
              <Truck className="w-12 h-12 text-[#25278C] mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Zero Upfront Cost</h3>
              <p className="text-gray-600">
                No payment required during the trial period. Only pay if you decide to purchase.
              </p>
            </div>

            <div className="bg-gray-50 rounded-xl p-8 text-center">
              <Shield className="w-12 h-12 text-[#25278C] mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-4">No Obligation</h3>
              <p className="text-gray-600">
                Walk away at the end of 90 days if you're not completely satisfied. No pressure.
              </p>
            </div>

            <div className="bg-gray-50 rounded-xl p-8 text-center">
              <Award className="w-12 h-12 text-[#25278C] mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Exclusive Pricing</h3>
              <p className="text-gray-600">
                Pilot participants receive 15% off full property orders placed within 30 days.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-2xl shadow-xl p-12 max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">Success Stories</h2>
              <p className="text-xl text-gray-600">Properties that trusted the pilot program</p>
            </div>

            <div className="space-y-8">
              <div className="border-l-4 border-[#25278C] pl-6">
                <p className="text-lg text-gray-700 mb-4 italic">
                  "We were skeptical about switching suppliers, but the pilot program removed all risk. After 90 days and overwhelmingly positive guest feedback, we ordered 85 mattresses for our entire property. Three years later, they still look and feel brand new."
                </p>
                <div className="font-semibold text-gray-900">Sarah Thompson</div>
                <div className="text-gray-600">Owner, Seascape Inn, St. Lucia (42 rooms)</div>
              </div>

              <div className="border-l-4 border-[#25278C] pl-6">
                <p className="text-lg text-gray-700 mb-4 italic">
                  "The trial let us test the Hotel Elite in our standard rooms and Hotel Luxury in our suites. Guest comment cards specifically mentioned mattress comfort. We made the full switch and haven't looked back."
                </p>
                <div className="font-semibold text-gray-900">David Chen</div>
                <div className="text-gray-600">Hotel Manager, Paradise Resort, Antigua (78 rooms)</div>
              </div>

              <div className="border-l-4 border-[#25278C] pl-6">
                <p className="text-lg text-gray-700 mb-4 italic">
                  "The data collection tools they provided were invaluable. We tracked feedback from 200+ guests during the trial. The results spoke for themselves - 94% satisfaction rate on mattress comfort."
                </p>
                <div className="font-semibold text-gray-900">Jennifer Williams</div>
                <div className="text-gray-600">General Manager, Coral Bay Hotel, Barbados (63 rooms)</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-[#25278C] to-[#1a1c66] text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Start Your Risk-Free Trial?</h2>
          <p className="text-xl mb-8 text-gray-200">
            Join the 50+ Caribbean properties that have successfully completed our pilot program. Apply now and we'll contact you within 24 hours.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/contact"
              className="bg-white hover:bg-gray-100 text-[#25278C] px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Submit Application
            </Link>
            <Link
              href="/hotel-line"
              className="border-2 border-white text-white hover:bg-white hover:text-[#25278C] px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              View Hotel Products
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
