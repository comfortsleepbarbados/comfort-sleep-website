'use client';

import Link from 'next/link';
import { Award, Shield, Clock, TrendingUp, Download, CheckCircle2, Star, Building2 } from 'lucide-react';

export default function Home() {
  return (
    <div className="pt-20">
      <section className="relative h-[90vh] bg-gradient-to-br from-gray-900 to-gray-800 flex items-center">
        <div
          className="absolute inset-0 z-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&w=1920')",
          }}
        ></div>
        <div className="absolute inset-0 bg-black/60 z-0"></div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
          <div className="max-w-3xl">
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
              Sleep Elevated.<br />
              <span className="text-gray-200">Luxury Comfort Designed for the Caribbean.</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-200">
              Mattresses engineered for tropical humidity, high turnover, and five-star guest expectations.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <Link
                href="/contact"
                className="bg-[#25278C] hover:bg-[#1a1c66] text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors text-center"
              >
                Request Quote
              </Link>
              <button className="bg-white hover:bg-gray-100 text-gray-900 px-8 py-4 rounded-lg text-lg font-semibold transition-colors flex items-center justify-center">
                <Download className="w-5 h-5 mr-2" />
                Download Hospitality Catalogue
              </button>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white/10 backdrop-blur-sm px-4 py-3 rounded-lg">
                <p className="text-sm font-semibold">EPA Certified</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm px-4 py-3 rounded-lg">
                <p className="text-sm font-semibold">ISO 9001</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm px-4 py-3 rounded-lg">
                <p className="text-sm font-semibold">7-Year Warranty</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm px-4 py-3 rounded-lg">
                <p className="text-sm font-semibold">Marriott Supplier</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Engineered for Caribbean Hospitality
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We understand the unique challenges of tropical luxury accommodation. Our mattresses deliver durability, comfort, and value.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-[#25278C]/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-[#25278C]" />
              </div>
              <h3 className="text-xl font-semibold mb-2">EPA & ISO Certified</h3>
              <p className="text-gray-600">
                Manufacturing excellence with internationally recognized quality standards.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-[#25278C]/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-8 h-8 text-[#25278C]" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Climate-Engineered</h3>
              <p className="text-gray-600">
                Specialized foam designed to perform in tropical humidity and heat.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-[#25278C]/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-[#25278C]" />
              </div>
              <h3 className="text-xl font-semibold mb-2">High Turnover Durability</h3>
              <p className="text-gray-600">
                Built to withstand frequent guest use while maintaining comfort.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-[#25278C]/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-[#25278C]" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Fast Fulfillment</h3>
              <p className="text-gray-600">
                2–3 week delivery for bulk orders across the Caribbean.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                The CARICOM Advantage
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Manufactured by Comfort Sleep in Guyana and distributed from Barbados, we offer CARICOM tariff-free pricing that makes premium quality accessible to Caribbean hospitality businesses.
              </p>

              <div className="space-y-4">
                <div className="flex items-start">
                  <CheckCircle2 className="w-6 h-6 text-[#25278C] mr-3 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">Zero Import Duties</h4>
                    <p className="text-gray-600">Save 20-35% compared to international imports</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <CheckCircle2 className="w-6 h-6 text-[#25278C] mr-3 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">Regional Logistics</h4>
                    <p className="text-gray-600">Faster shipping, lower costs, better support</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <CheckCircle2 className="w-6 h-6 text-[#25278C] mr-3 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">Local Accountability</h4>
                    <p className="text-gray-600">Caribbean-based warranty service and support</p>
                  </div>
                </div>
              </div>

              <Link
                href="/hotel-line"
                className="inline-block mt-8 bg-[#25278C] hover:bg-[#1a1c66] text-white px-8 py-3 rounded-lg font-semibold transition-colors"
              >
                Explore Hotel Line
              </Link>
            </div>

            <div className="relative h-96 rounded-lg overflow-hidden shadow-2xl">
              <img
                src="https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=1200"
                alt="Luxury hotel bedroom"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Trusted By
            </h2>
            <p className="text-xl text-gray-600 mb-12">
              Proud partners of leading Caribbean hospitality brands
            </p>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 items-center justify-items-center">
              <img
                src="https://www.comfortsleepbarbados.com/cdn/shop/files/Icons_-_Shopify_Website_5f268000-fd35-4b6a-a139-1fb205c0de10_300x300.png"
                alt="Partner Logo"
                className="h-16 w-auto grayscale hover:grayscale-0 transition-all"
              />
              <img
                src="https://www.comfortsleepbarbados.com/cdn/shop/files/11_300x300.png"
                alt="Partner Logo"
                className="h-16 w-auto grayscale hover:grayscale-0 transition-all"
              />
              <img
                src="https://www.comfortsleepbarbados.com/cdn/shop/files/8_300x300.png"
                alt="Partner Logo"
                className="h-16 w-auto grayscale hover:grayscale-0 transition-all"
              />
              <img
                src="https://www.comfortsleepbarbados.com/cdn/shop/files/2_300x300.png"
                alt="Partner Logo"
                className="h-16 w-auto grayscale hover:grayscale-0 transition-all"
              />
              <img
                src="https://www.comfortsleepbarbados.com/cdn/shop/files/9_300x300.png"
                alt="Partner Logo"
                className="h-16 w-auto grayscale hover:grayscale-0 transition-all"
              />
              <img
                src="https://www.comfortsleepbarbados.com/cdn/shop/files/6_300x300.png"
                alt="Partner Logo"
                className="h-16 w-auto grayscale hover:grayscale-0 transition-all"
              />
              <img
                src="https://www.comfortsleepbarbados.com/cdn/shop/files/5_300x300.png"
                alt="Partner Logo"
                className="h-16 w-auto grayscale hover:grayscale-0 transition-all"
              />
              <img
                src="https://www.comfortsleepbarbados.com/cdn/shop/files/3_300x300.png"
                alt="Partner Logo"
                className="h-16 w-auto grayscale hover:grayscale-0 transition-all"
              />
              <img
                src="https://www.comfortsleepbarbados.com/cdn/shop/files/10_300x300.png"
                alt="Partner Logo"
                className="h-16 w-auto grayscale hover:grayscale-0 transition-all"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-[#25278C] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">
              Performance That Speaks for Itself
            </h2>
            <p className="text-xl text-gray-200">
              Numbers that demonstrate our commitment to Caribbean hospitality excellence
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">250+</div>
              <div className="text-gray-200">Properties Served</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">15,000+</div>
              <div className="text-gray-200">Mattresses Delivered</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">12</div>
              <div className="text-gray-200">Caribbean Islands</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold mb-2">98%</div>
              <div className="text-gray-200">Client Satisfaction</div>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-8">
            <div className="flex items-center mb-4">
              <Star className="w-6 h-6 text-yellow-400 fill-current" />
              <Star className="w-6 h-6 text-yellow-400 fill-current" />
              <Star className="w-6 h-6 text-yellow-400 fill-current" />
              <Star className="w-6 h-6 text-yellow-400 fill-current" />
              <Star className="w-6 h-6 text-yellow-400 fill-current" />
            </div>
            <p className="text-lg mb-4 italic">
              "Comfort Sleep transformed our guest experience. Their Hotel Elite line has maintained exceptional quality through three years of high occupancy. The CARICOM pricing made the upgrade possible for all 120 rooms."
            </p>
            <div className="flex items-center">
              <Building2 className="w-12 h-12 text-white/60 mr-4" />
              <div>
                <div className="font-semibold">Michael Richards</div>
                <div className="text-gray-300">General Manager, Crane Resort</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-8 rounded-lg">
              <h3 className="text-2xl font-bold mb-4 text-gray-900">7-Year Commercial Warranty</h3>
              <p className="text-gray-600 mb-6">
                Comprehensive coverage transferable between property owners. Full replacement guarantee for manufacturing defects.
              </p>
              <Link
                href="/warranty"
                className="text-[#25278C] font-semibold hover:underline"
              >
                Learn More →
              </Link>
            </div>

            <div className="bg-gray-50 p-8 rounded-lg">
              <h3 className="text-2xl font-bold mb-4 text-gray-900">Try Before You Buy</h3>
              <p className="text-gray-600 mb-6">
                Our Pilot Program lets you test our Hotel Line in select rooms for 90 days before committing to a full property order.
              </p>
              <Link
                href="/pilot-program"
                className="text-[#25278C] font-semibold hover:underline"
              >
                Apply Now →
              </Link>
            </div>

            <div className="bg-gray-50 p-8 rounded-lg">
              <h3 className="text-2xl font-bold mb-4 text-gray-900">Bulk Order Pricing</h3>
              <p className="text-gray-600 mb-6">
                Volume discounts available for properties with 20+ rooms. Flexible payment terms for qualified hospitality businesses.
              </p>
              <Link
                href="/contact"
                className="text-[#25278C] font-semibold hover:underline"
              >
                Get Quote →
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gradient-to-br from-[#25278C] to-[#1a1c66] text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">
            Ready to Elevate Your Guest Experience?
          </h2>
          <p className="text-xl mb-8 text-gray-200">
            Schedule a consultation with our hospitality team to discuss your property's specific needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/contact"
              className="bg-white hover:bg-gray-100 text-[#25278C] px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
            >
              Book Consultation
            </Link>
            <button className="border-2 border-white hover:bg-white hover:text-[#25278C] text-white px-8 py-4 rounded-lg text-lg font-semibold transition-colors">
              Download Catalogue
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
